import urllib.request
urllib.request.urlretrieve ("https://downloads.openwrt.org/snapshots/targets/ramips/mt7621/openwrt-ramips-mt7621-xiaomi_mir3g-v2-squashfs-sysupgrade.bin", "firmwares/openwrt-ramips-mt7621-xiaomi_mir3g-v2-squashfs-sysupgrade.bin")
